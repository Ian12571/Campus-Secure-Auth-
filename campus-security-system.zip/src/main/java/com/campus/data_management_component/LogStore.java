package com.campus.data_management_component;

import com.campus.problem_domain_component.AccessLog;
import java.util.ArrayList;
import java.util.List;

// LogStore class
public class LogStore {
    private List<AccessLog> logs = new ArrayList<>();
    
    public void recordAccess(AccessLog log) {
        logs.add(log);
        log.createEntry();
    }
    
    public List<AccessLog> queryLogs(int limit) {
        int size = logs.size();
        int startIndex = Math.max(0, size - limit);
        return logs.subList(startIndex, size);
    }
    
    public List<AccessLog> queryLogsByStudent(String studentID) {
        List<AccessLog> studentLogs = new ArrayList<>();
        for (AccessLog log : logs) {
            if (log.getStudentID().equals(studentID)) {
                studentLogs.add(log);
            }
        }
        return studentLogs;
    }
    
    public int getLogCount() {
        return logs.size();
    }
}
