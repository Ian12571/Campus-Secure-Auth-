package com.campus.data_management_component;

import java.util.ArrayList;
import java.util.List;

// AlertStore class
public class AlertStore {
    private List<Alert> alerts = new ArrayList<>();
    
    public void addAlert(Alert alert) {
        alerts.add(alert);
    }
    
    public List<Alert> getActiveAlerts() {
        List<Alert> activeAlerts = new ArrayList<>();
        for (Alert alert : alerts) {
            if (alert.isActive()) {
                activeAlerts.add(alert);
            }
        }
        return activeAlerts;
    }
    
    public void resolveAlert(int index) {
        if (index >= 0 && index < alerts.size()) {
            alerts.get(index).resolve();
        }
    }
    
    public int getAlertCount() {
        return alerts.size();
    }
}