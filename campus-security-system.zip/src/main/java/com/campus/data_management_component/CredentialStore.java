package com.campus.data_management_component;

import java.util.HashMap;
import java.util.Map;
import com.campus.problem_domain_component.Student;

// CredentialStore class
public class CredentialStore {
    private Map<String, Student> studentsByCard = new HashMap<>();
    
    public void addStudent(Student student) {
        studentsByCard.put(student.getCardID(), student);
    }
    
    public Student findStudentByCard(String cardID) {
        return studentsByCard.get(cardID);
    }
    
    public void updateStudent(Student student) {
        studentsByCard.put(student.getCardID(), student);
    }
    
    public void removeStudent(String cardID) {
        studentsByCard.remove(cardID);
    }
    
    public int getStudentCount() {
        return studentsByCard.size();
    }
}
