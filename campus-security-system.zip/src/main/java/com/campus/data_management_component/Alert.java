package com.campus.data_management_component;


// Alert class
public class Alert {
    private long timestamp;
    private String message;
    private boolean active;
    
    public Alert(long timestamp, String message) {
        this.timestamp = timestamp;
        this.message = message;
        this.active = true;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public String getMessage() {
        return message;
    }
    
    public boolean isActive() {
        return active;
    }
    
    public void resolve() {
        active = false;
    }
    
    @Override
    public String toString() {
        return "Alert{" +
                "timestamp=" + timestamp +
                ", message='" + message + '\'' +
                ", active=" + active +
                '}';
    }
}
