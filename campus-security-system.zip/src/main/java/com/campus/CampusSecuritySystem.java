package com.campus;

// Main class to run the system
import java.util.*;

import com.campus.data_management_component.AlertStore;
import com.campus.data_management_component.CredentialStore;
import com.campus.data_management_component.LogStore;
import com.campus.human_interaction_component.AdminDashboard;
import com.campus.human_interaction_component.ScannerUI;
import com.campus.human_interaction_component.StatusDisplay;
import com.campus.problem_domain_component.AccessPoint;
import com.campus.problem_domain_component.AlertManager;
import com.campus.problem_domain_component.AuthenticationManager;
import com.campus.problem_domain_component.Student;

public class CampusSecuritySystem {
    public static void main(String[] args) {
        // Initialize the system components
        CredentialStore credStore = new CredentialStore();
        LogStore logStore = new LogStore();
        AlertStore alertStore = new AlertStore();
        AlertManager alertManager = new AlertManager(alertStore);
        AuthenticationManager authManager = new AuthenticationManager(credStore, logStore, alertManager);
        
        // Create some sample students
        Student student1 = new Student("S001", "John Doe", "C001");
        Student student2 = new Student("S002", "Jane Smith", "C002");
        Student student3 = new Student("S003", "Bob Johnson", "C003");
        
        // Add students to credential store
        credStore.addStudent(student1);
        credStore.addStudent(student2);
        credStore.addStudent(student3);
        
        // Create access points
        AccessPoint library = new AccessPoint("D001", "Library", authManager);
        AccessPoint lab = new AccessPoint("D002", "Computer Lab", authManager);
        
        // Create UI components
        StatusDisplay statusDisplay = new StatusDisplay();
        ScannerUI scannerUI = new ScannerUI(statusDisplay);
        AdminDashboard adminDashboard = new AdminDashboard(logStore, alertStore);
        
        // Simulate some scans
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        
        System.out.println("==== Campus Security Authentication System ====");
        System.out.println("Available commands:");
        System.out.println("1. Scan card (scan <card_id> <door_id>)");
        System.out.println("2. View logs (logs)");
        System.out.println("3. View alerts (alerts)");
        System.out.println("4. Exit (exit)");
        
        while (running) {
            System.out.print("> ");
            String input = scanner.nextLine();
            String[] parts = input.split(" ");
            
            if (parts[0].equalsIgnoreCase("scan")) {
                if (parts.length >= 3) {
                    String cardID = parts[1];
                    String doorID = parts[2];
                    AccessPoint door = doorID.equals("D001") ? library : lab;
                    
                    scannerUI.promptScan();
                    boolean result = door.scanCard(cardID);
                    
                    // Find student name for display
                    Student student = credStore.findStudentByCard(cardID);
                    String name = student != null ? student.getName() : "Unknown";
                    
                    scannerUI.displayResult(result, name);
                } else {
                    System.out.println("Usage: scan <card_id> <door_id>");
                }
            } else if (parts[0].equalsIgnoreCase("logs")) {
                adminDashboard.viewLogs();
            } else if (parts[0].equalsIgnoreCase("alerts")) {
                adminDashboard.viewAlerts();
            } else if (parts[0].equalsIgnoreCase("exit")) {
                running = false;
                System.out.println("System shutting down...");
            } else {
                System.out.println("Unknown command. Try scan, logs, alerts, or exit.");
            }
        }
        
        scanner.close();
    }
}
