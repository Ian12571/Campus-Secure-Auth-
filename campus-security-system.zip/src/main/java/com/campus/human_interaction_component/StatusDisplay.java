package com.campus.human_interaction_component;

import java.util.ArrayList;
import java.util.List;

// StatusDisplay class
public class StatusDisplay {
    private List<String> recentStatuses = new ArrayList<>();
    private static final int MAX_STATUSES = 5;
    
    public void updateStatus(String status) {
        recentStatuses.add(0, status); // Add to beginning
        
        // Keep only the most recent statuses
        if (recentStatuses.size() > MAX_STATUSES) {
            recentStatuses.remove(recentStatuses.size() - 1);
        }
        
        displayCurrentStatus();
    }
    
    private void displayCurrentStatus() {
        System.out.println("=== STATUS DISPLAY ===");
        for (String status : recentStatuses) {
            System.out.println(status);
        }
        System.out.println("=====================");
    }
}