package com.campus.human_interaction_component;

import java.util.List;

import com.campus.data_management_component.Alert;
import com.campus.data_management_component.AlertStore;
import com.campus.data_management_component.LogStore;
import com.campus.problem_domain_component.AccessLog;

// AdminDashboard class
public class AdminDashboard {
    private LogStore logStore;
    private AlertStore alertStore;
    
    public AdminDashboard(LogStore logStore, AlertStore alertStore) {
        this.logStore = logStore;
        this.alertStore = alertStore;
    }
    
    public void viewLogs() {
        System.out.println("=== ACCESS LOGS ===");
        List<AccessLog> recentLogs = logStore.queryLogs(10); // Get 10 most recent
        for (AccessLog log : recentLogs) {
            System.out.println(log);
        }
        System.out.println("==================");
    }
    
    public void viewAlerts() {
        System.out.println("=== ACTIVE ALERTS ===");
        List<Alert> activeAlerts = alertStore.getActiveAlerts();
        for (Alert alert : activeAlerts) {
            System.out.println(alert);
        }
        System.out.println("====================");
    }
}
