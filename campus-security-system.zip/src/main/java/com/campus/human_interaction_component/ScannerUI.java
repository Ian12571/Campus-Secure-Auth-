package com.campus.human_interaction_component;

// ScannerUI class
public class ScannerUI {
    private StatusDisplay statusDisplay;
    
    public ScannerUI(StatusDisplay statusDisplay) {
        this.statusDisplay = statusDisplay;
    }
    
    public void promptScan() {
        System.out.println("Please scan your RFID card");
    }
    
    public void displayResult(boolean accessGranted, String studentName) {
        String message = accessGranted ? 
            "Access Granted: Welcome, " + studentName :
            "Access Denied";
        System.out.println(message);
        
        // Update the status display
        statusDisplay.updateStatus(message);
    }
}
