package com.campus;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ScannerWindow extends Application {

    private Label statusLabel;

    @Override
    public void start(Stage primaryStage) {
        statusLabel = new Label("Please scan your RFID card");
        Button scanButton = new Button("Simulate Scan");

        scanButton.setOnAction(_ -> {
            boolean accessGranted = true; // Later replace with CredentialStore logic
            String message = accessGranted ? "Access Granted: Welcome!" : "Access Denied";
            statusLabel.setText(message);
        });

        VBox layout = new VBox(10, statusLabel, scanButton);
        Scene scene = new Scene(layout, 300, 150);
        primaryStage.setTitle("Campus Gate Authentication");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
