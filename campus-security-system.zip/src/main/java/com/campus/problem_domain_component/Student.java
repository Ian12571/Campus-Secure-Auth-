package com.campus.problem_domain_component;
// Student class
public class Student {
    private String studentID;
    private String name;
    private String cardID;
    
    public Student(String studentID, String name, String cardID) {
        this.studentID = studentID;
        this.name = name;
        this.cardID = cardID;
    }
    
    public String getStudentID() {
        return studentID;
    }
    
    public String getName() {
        return name;
    }
    
    public String getCardID() {
        return cardID;
    }
    
    public void requestAccess() {
        System.out.println("Student " + name + " requesting access");
    }
    
    public void reportIssue(String issue) {
        System.out.println("Student " + name + " reporting issue: " + issue);
    }
}
