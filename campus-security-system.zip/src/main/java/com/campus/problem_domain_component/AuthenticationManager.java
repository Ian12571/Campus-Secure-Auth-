package com.campus.problem_domain_component;

import com.campus.data_management_component.LogStore;
import com.campus.data_management_component.CredentialStore;

// AuthenticationManager class
public class AuthenticationManager {
    private CredentialStore credStore;
    private LogStore logStore;
    private AlertManager alertManager;
    
    public AuthenticationManager(CredentialStore credStore, LogStore logStore, AlertManager alertManager) {
        this.credStore = credStore;
        this.logStore = logStore;
        this.alertManager = alertManager;
    }
    
    public boolean verifyCard(String cardID, String doorID) {
        Student student = credStore.findStudentByCard(cardID);
        boolean accessGranted = false;
        
        if (student != null) {
            // Check if the card is valid
            RFIDCard card = new RFIDCard(cardID);
            if (card.isActive()) {
                accessGranted = true;
                System.out.println("Access granted to " + student.getName());
            } else {
                System.out.println("Card is inactive");
            }
        } else {
            System.out.println("Unknown card or student");
        }
        
        // Create log entry
        AccessLog log = new AccessLog(
            System.currentTimeMillis(),
            student != null ? student.getStudentID() : "unknown",
            doorID,
            accessGranted
        );
        
        // Record the access attempt
        logStore.recordAccess(log);
        
        // Check for alerts
        alertManager.checkAlerts(log);
        
        return accessGranted;
    }
    
    public void processScan(String cardID, String doorID) {
        verifyCard(cardID, doorID);
    }
}
