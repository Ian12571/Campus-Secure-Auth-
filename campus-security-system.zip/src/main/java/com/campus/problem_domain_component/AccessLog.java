package com.campus.problem_domain_component;

// AccessLog class
public class AccessLog {
    private long timestamp;
    private String studentID;
    private String doorID;
    private boolean accessGranted;
    
    public AccessLog(long timestamp, String studentID, String doorID, boolean accessGranted) {
        this.timestamp = timestamp;
        this.studentID = studentID;
        this.doorID = doorID;
        this.accessGranted = accessGranted;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public String getStudentID() {
        return studentID;
    }
    
    public String getDoorID() {
        return doorID;
    }
    
    public boolean isAccessGranted() {
        return accessGranted;
    }
    
    public void createEntry() {
        System.out.println("Log entry created: " + toString());
    }
    
    @Override
    public String toString() {
        return "AccessLog{" +
                "timestamp=" + timestamp +
                ", studentID='" + studentID + '\'' +
                ", doorID='" + doorID + '\'' +
                ", accessGranted=" + accessGranted +
                '}';
    }
}
