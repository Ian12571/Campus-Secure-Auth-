package com.campus.problem_domain_component;

// AccessPoint class
public class AccessPoint {
    private String doorID;
    private String location;
    private AuthenticationManager authManager;
    
    public AccessPoint(String doorID, String location, AuthenticationManager authManager) {
        this.doorID = doorID;
        this.location = location;
        this.authManager = authManager;
    }
    
    public String getDoorID() {
        return doorID;
    }
    
    public String getLocation() {
        return location;
    }
    
    public boolean scanCard(String cardID) {
        System.out.println("Card scanned at door " + doorID + " (" + location + ")");
        boolean accessGranted = authManager.verifyCard(cardID, this.doorID);
        
        if (accessGranted) {
            unlockDoor();
        }
        
        return accessGranted;
    }
    
    public void unlockDoor() {
        System.out.println("Door " + doorID + " unlocked");
    }
    
    public void lockDoor() {
        System.out.println("Door " + doorID + " locked");
    }
}
