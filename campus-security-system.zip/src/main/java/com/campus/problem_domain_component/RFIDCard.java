package com.campus.problem_domain_component;
// RFIDCard class
public class RFIDCard {
    private String cardID;
    private boolean status; // true for active, false for inactive
    
    public RFIDCard(String cardID) {
        this.cardID = cardID;
        this.status = true; // Default to active
    }
    
    public String getCardID() {
        return cardID;
    }
    
    public boolean isActive() {
        return status;
    }
    
    public void activate() {
        status = true;
        System.out.println("Card " + cardID + " activated");
    }
    
    public void deactivate() {
        status = false;
        System.out.println("Card " + cardID + " deactivated");
    }
}
