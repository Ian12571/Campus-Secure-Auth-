package com.campus.problem_domain_component;

import java.util.HashMap;
import java.util.Map;
import com.campus.data_management_component.Alert;
import com.campus.data_management_component.AlertStore;

// AlertManager class
public class AlertManager {
    private AlertStore alertStore;
    private Map<String, Integer> failedAttempts = new HashMap<>();
    private static final int MAX_FAILED_ATTEMPTS = 3;
    
    public AlertManager(AlertStore alertStore) {
        this.alertStore = alertStore;
    }
    
    public void checkAlerts(AccessLog log) {
        if (!log.isAccessGranted()) {
            // Count failed attempts
            String studentID = log.getStudentID();
            int attempts = failedAttempts.getOrDefault(studentID, 0) + 1;
            failedAttempts.put(studentID, attempts);
            
            if (attempts >= MAX_FAILED_ATTEMPTS) {
                generateAlert("Multiple failed access attempts for student " + studentID);
                failedAttempts.put(studentID, 0); // Reset counter after alert
            }
        } else {
            // Reset counter on successful access
            failedAttempts.put(log.getStudentID(), 0);
        }
    }
    
    public void generateAlert(String message) {
        Alert alert = new Alert(System.currentTimeMillis(), message);
        alertStore.addAlert(alert);
        System.out.println("ALERT: " + message);
    }
}